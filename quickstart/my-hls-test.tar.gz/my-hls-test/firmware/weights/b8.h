//Numpy array shape [5]
//Min -0.321016222239
//Max 0.425187110901
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
model_default_t b8[5];
#else
model_default_t b8[5] = {-0.3210162222, 0.1269035041, 0.4251871109, -0.1555743665, 0.0194655824};
#endif

#endif
